import { CartProvider } from "./context/CartContext";
import MotionBackground from "./components/MotionBackground";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Marquee from "./components/Marquee";
import Catalog from "./components/Catalog";
import Features from "./components/Features";
import Contact from "./components/Contact";
import Footer from "./components/Footer";
import CartDrawer from "./components/CartDrawer";

export default function App() {
  return (
    <CartProvider>
      <div className="relative min-h-screen overflow-x-hidden bg-ink text-white">
        {/* base radial vignette */}
        <div className="pointer-events-none fixed inset-0 -z-20 bg-[radial-gradient(ellipse_at_top,_rgba(60,50,120,0.25),_transparent_55%)]" />

        {/* animated gradient orbs */}
        <div className="pointer-events-none fixed inset-0 -z-20 overflow-hidden">
          <div className="absolute -left-32 top-10 h-96 w-96 rounded-full bg-violet-600/25 blur-[120px] animate-float-slow" />
          <div className="absolute right-0 top-1/3 h-[28rem] w-[28rem] rounded-full bg-cyan-500/20 blur-[130px] animate-float-slow" style={{ animationDelay: "2s" }} />
          <div className="absolute bottom-0 left-1/3 h-96 w-96 rounded-full bg-fuchsia-600/15 blur-[120px] animate-float-slow" style={{ animationDelay: "4s" }} />
        </div>

        {/* live particle background */}
        <MotionBackground />

        <Navbar />
        <main>
          <Hero />
          <Marquee />
          <Catalog />
          <Features />
          <Contact />
        </main>
        <Footer />
        <CartDrawer />
      </div>
    </CartProvider>
  );
}
