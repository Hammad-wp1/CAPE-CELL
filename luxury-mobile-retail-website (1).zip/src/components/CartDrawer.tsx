import { AnimatePresence, motion } from "framer-motion";
import { useState } from "react";
import { useCart } from "../context/CartContext";
import { formatZar } from "../data/products";

export default function CartDrawer() {
  const { items, isOpen, setOpen, remove, setQty, total, count, clear } = useCart();
  const [done, setDone] = useState(false);

  const checkout = () => {
    const lines = items
      .map((i) => `• ${i.name} ×${i.qty} — ${formatZar(i.price * i.qty)}`)
      .join("%0A");
    const body = `Hi CAPE CELL, I'd like to order:%0A%0A${lines}%0A%0ATotal: ${formatZar(total)}`;
    window.location.href = `mailto:capecell021@gmail.com?subject=${encodeURIComponent(
      "New Order — CAPE CELL"
    )}&body=${body}`;
    setDone(true);
    setTimeout(() => {
      setDone(false);
      clear();
      setOpen(false);
    }, 2500);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setOpen(false)}
            className="fixed inset-0 z-[60] bg-black/60 backdrop-blur-sm"
          />
          <motion.aside
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 30, stiffness: 280 }}
            className="fixed right-0 top-0 z-[70] flex h-full w-full max-w-md flex-col border-l border-white/10 bg-ink-soft/95 backdrop-blur-xl"
          >
            <div className="flex items-center justify-between border-b border-white/8 p-5">
              <div>
                <h3 className="font-display text-lg font-700">Your Cart</h3>
                <p className="text-xs text-white/40">{count} item{count !== 1 ? "s" : ""}</p>
              </div>
              <button
                onClick={() => setOpen(false)}
                className="flex h-9 w-9 items-center justify-center rounded-xl border border-white/10 bg-white/5 transition-colors hover:bg-white/10"
                aria-label="Close cart"
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M18 6 6 18M6 6l12 12" /></svg>
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-5">
              {items.length === 0 ? (
                <div className="flex h-full flex-col items-center justify-center text-center text-white/50">
                  <div className="mb-4 text-5xl">🛍️</div>
                  <p className="font-medium text-white">Your cart is empty</p>
                  <p className="mt-1 text-sm">Add a device to get started.</p>
                  <button onClick={() => setOpen(false)} className="mt-6 rounded-xl bg-gradient-to-r from-violet-500 to-cyan-400 px-5 py-2.5 text-sm font-semibold text-ink">
                    Browse devices
                  </button>
                </div>
              ) : (
                <ul className="space-y-3">
                  <AnimatePresence>
                    {items.map((i) => (
                      <motion.li
                        key={i.id}
                        layout
                        initial={{ opacity: 0, x: 30 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 30, height: 0 }}
                        className="flex gap-3 rounded-2xl border border-white/8 bg-white/[0.03] p-3"
                      >
                        <div
                          className="relative h-16 w-14 shrink-0 overflow-hidden rounded-xl border border-white/10"
                        >
                          <img
                            src={i.image}
                            alt={i.name}
                            className="h-full w-full object-cover"
                          />
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-start justify-between gap-2">
                            <h4 className="truncate text-sm font-semibold text-white">{i.name}</h4>
                            <button onClick={() => remove(i.id)} className="text-white/30 transition-colors hover:text-red-400" aria-label="Remove">
                              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" /></svg>
                            </button>
                          </div>
                          <div className="text-xs text-white/40">{i.brand}</div>
                          <div className="mt-2 flex items-center justify-between">
                            <div className="flex items-center gap-2 rounded-lg border border-white/10 bg-white/5 px-1">
                              <button onClick={() => setQty(i.id, i.qty - 1)} className="flex h-6 w-6 items-center justify-center text-white/70 hover:text-white">−</button>
                              <span className="w-5 text-center text-sm">{i.qty}</span>
                              <button onClick={() => setQty(i.id, i.qty + 1)} className="flex h-6 w-6 items-center justify-center text-white/70 hover:text-white">+</button>
                            </div>
                            <span className="font-display text-sm font-700 text-white">{formatZar(i.price * i.qty)}</span>
                          </div>
                        </div>
                      </motion.li>
                    ))}
                  </AnimatePresence>
                </ul>
              )}
            </div>

            {items.length > 0 && (
              <div className="border-t border-white/8 p-5">
                <div className="mb-1 flex justify-between text-sm text-white/50">
                  <span>Delivery</span>
                  <span className="text-emerald-400">Free</span>
                </div>
                <div className="mb-4 flex items-end justify-between">
                  <span className="text-sm text-white/60">Total</span>
                  <span className="font-display text-2xl font-800 text-gradient">{formatZar(total)}</span>
                </div>
                <button
                  onClick={checkout}
                  disabled={done}
                  className="w-full rounded-xl bg-gradient-to-r from-violet-500 to-cyan-400 py-3.5 font-semibold text-ink transition-transform hover:scale-[1.01] disabled:opacity-70"
                >
                  {done ? "✓ Order placed!" : "Checkout"}
                </button>
                <p className="mt-3 text-center text-[11px] text-white/35">
                  Secure checkout · we'll confirm your order by email & phone
                </p>
              </div>
            )}
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}
