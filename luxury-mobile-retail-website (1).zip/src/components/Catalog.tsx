import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { products, BRANDS, CATEGORIES } from "../data/products";
import ProductCard from "./ProductCard";

export default function Catalog() {
  const [brand, setBrand] = useState<(typeof BRANDS)[number]>("All");
  const [cat, setCat] = useState<(typeof CATEGORIES)[number]>("All");
  const [q, setQ] = useState("");

  const filtered = useMemo(() => {
    return products.filter((p) => {
      const b = brand === "All" || p.brand === brand;
      const c = cat === "All" || p.category === cat;
      const s =
        q.trim() === "" ||
        p.name.toLowerCase().includes(q.toLowerCase()) ||
        p.tagline.toLowerCase().includes(q.toLowerCase()) ||
        p.brand.toLowerCase().includes(q.toLowerCase()) ||
        p.category.toLowerCase().includes(q.toLowerCase());
      return b && c && s;
    });
  }, [brand, cat, q]);

  const clearFilters = () => {
    setBrand("All");
    setCat("All");
    setQ("");
  };

  return (
    <section id="shop" className="relative mx-auto max-w-7xl scroll-mt-24 px-5 py-20 sm:py-28">
      <div className="mb-10 text-center">
        <motion.span
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-xs font-semibold uppercase tracking-[0.3em] text-cyan-300/70"
        >
          The Collection
        </motion.span>
        <motion.h2
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-3 font-display text-3xl font-800 tracking-tight sm:text-5xl"
        >
          Every device. <span className="text-gradient">One ecosystem.</span>
        </motion.h2>
        <p className="mx-auto mt-4 max-w-2xl text-white/55">
          Browse the entire Apple and Samsung line-up — handpicked, authentic and ready to ship.
        </p>
      </div>

      {/* controls */}
      <div className="glass sticky top-20 z-30 mb-10 flex flex-col gap-4 rounded-2xl p-4 shadow-2xl shadow-black/45 backdrop-blur-xl">
        <div className="flex flex-col items-stretch gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex flex-wrap gap-2">
            {BRANDS.map((b) => (
              <button
                key={b}
                onClick={() => {
                  setBrand(b);
                }}
                className={`rounded-xl px-4 py-2 text-sm font-semibold transition-all duration-300 ${
                  brand === b
                    ? "bg-gradient-to-r from-violet-500 to-cyan-400 text-ink shadow-lg shadow-violet-500/20 scale-[1.02]"
                    : "border border-white/10 bg-white/5 text-white/70 hover:bg-white/10"
                }`}
              >
                {b}
              </button>
            ))}
          </div>
          
          {/* Enhanced search box with clear input option */}
          <div className="relative w-full lg:w-96">
            <svg className="absolute left-3.5 top-1/2 -translate-y-1/2 text-cyan-300/60" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="11" cy="11" r="8" />
              <path d="m21 21-4.3-4.3" />
            </svg>
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search by device, category, specs..."
              className="w-full rounded-xl border border-white/10 bg-white/5 py-3 pl-10 pr-10 text-sm text-white placeholder:text-white/40 outline-none transition-all duration-300 focus:border-cyan-400/50 focus:ring-1 focus:ring-cyan-400/30 focus:bg-white/10"
            />
            {q && (
              <button
                onClick={() => setQ("")}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-white/40 hover:text-white transition-colors"
                aria-label="Clear search"
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M18 6 6 18M6 6l12 12" /></svg>
              </button>
            )}
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-white/5 pt-3">
          <div className="flex flex-wrap gap-1.5">
            {CATEGORIES.map((c) => (
              <button
                key={c}
                onClick={() => setCat(c)}
                className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition-all duration-300 ${
                  cat === c
                    ? "bg-white/20 text-white shadow"
                    : "text-white/50 hover:bg-white/5 hover:text-white/80"
                }`}
              >
                {c}
              </button>
            ))}
          </div>

          {/* Results feedback badge */}
          <div className="text-xs font-medium text-white/55 bg-white/5 border border-white/8 rounded-lg px-2.5 py-1 flex items-center gap-1.5">
            <span className="relative flex h-1.5 w-1.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-cyan-400 opacity-75"></span>
              <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-cyan-400"></span>
            </span>
            {filtered.length} {filtered.length === 1 ? "device" : "devices"} found
          </div>
        </div>
      </div>

      {/* grid */}
      <motion.div layout className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        <AnimatePresence mode="popLayout">
          {filtered.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </AnimatePresence>
      </motion.div>

      {filtered.length === 0 && (
        <div className="py-24 text-center rounded-3xl border border-white/5 bg-white/[0.02] p-8 max-w-lg mx-auto">
          <div className="mb-4 text-5xl">🔍</div>
          <h3 className="font-display text-lg font-700 text-white">No devices found</h3>
          <p className="mt-2 text-sm text-white/50">
            We couldn't find any devices matching "{q || cat || brand}". Try adjusting your filters.
          </p>
          <button
            onClick={clearFilters}
            className="mt-6 rounded-xl bg-gradient-to-r from-violet-500 to-cyan-400 px-5 py-2.5 text-sm font-semibold text-ink transition-transform hover:scale-105"
          >
            Clear all filters
          </button>
        </div>
      )}
    </section>
  );
}
