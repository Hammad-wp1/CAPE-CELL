import { useState } from "react";
import { motion } from "framer-motion";

export default function Contact() {
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", msg: "" });

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const subject = encodeURIComponent(`CAPE CELL enquiry from ${form.name || "a customer"}`);
    const body = encodeURIComponent(`${form.msg}\n\nFrom: ${form.name}\nEmail: ${form.email}`);
    window.location.href = `mailto:capecell021@gmail.com?subject=${subject}&body=${body}`;
    setSent(true);
    setTimeout(() => setSent(false), 4000);
  };

  return (
    <section id="contact" className="relative mx-auto max-w-7xl scroll-mt-24 px-5 py-20 sm:py-28">
      <div className="glass relative overflow-hidden rounded-[2rem] p-7 sm:p-12">
        <div className="pointer-events-none absolute -left-20 -top-20 h-64 w-64 rounded-full bg-violet-600/20 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-20 -right-20 h-64 w-64 rounded-full bg-cyan-400/20 blur-3xl" />

        <div className="relative grid gap-10 lg:grid-cols-2">
          <div>
            <span className="text-xs font-semibold uppercase tracking-[0.3em] text-cyan-300/70">
              Get in touch
            </span>
            <h2 className="mt-3 font-display text-3xl font-800 tracking-tight sm:text-4xl">
              Let's find your <span className="text-gradient">perfect device.</span>
            </h2>
            <p className="mt-4 max-w-md text-white/55">
              Questions about stock, trade-ins or instalments? Our specialists reply fast — usually within the hour.
            </p>

            <div className="mt-8 space-y-3">
              <a href="mailto:capecell021@gmail.com" className="group flex items-center gap-4 rounded-2xl border border-white/8 bg-white/[0.03] p-4 transition-colors hover:border-white/20">
                <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500 to-cyan-400 text-ink">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="4" width="20" height="16" rx="2" /><path d="m22 7-10 5L2 7" /></svg>
                </span>
                <div>
                  <div className="text-xs text-white/40">Email us</div>
                  <div className="font-medium text-white">capecell021@gmail.com</div>
                </div>
              </a>
              <a href="tel:0611677250" className="group flex items-center gap-4 rounded-2xl border border-white/8 bg-white/[0.03] p-4 transition-colors hover:border-white/20">
                <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500 to-cyan-400 text-ink">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z" /></svg>
                </span>
                <div>
                  <div className="text-xs text-white/40">Call or WhatsApp</div>
                  <div className="font-medium text-white">061 167 7250</div>
                </div>
              </a>
            </div>
          </div>

          <motion.form
            onSubmit={submit}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="space-y-4 rounded-3xl border border-white/8 bg-white/[0.03] p-6"
          >
            <div>
              <label className="mb-1.5 block text-xs font-medium text-white/60">Name</label>
              <input
                required
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white placeholder:text-white/30 outline-none focus:border-violet-400/60"
                placeholder="Your name"
              />
            </div>
            <div>
              <label className="mb-1.5 block text-xs font-medium text-white/60">Email</label>
              <input
                required
                type="email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white placeholder:text-white/30 outline-none focus:border-violet-400/60"
                placeholder="you@email.com"
              />
            </div>
            <div>
              <label className="mb-1.5 block text-xs font-medium text-white/60">Message</label>
              <textarea
                required
                rows={4}
                value={form.msg}
                onChange={(e) => setForm({ ...form, msg: e.target.value })}
                className="w-full resize-none rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white placeholder:text-white/30 outline-none focus:border-violet-400/60"
                placeholder="Which device are you after?"
              />
            </div>
            <button
              type="submit"
              className="w-full rounded-xl bg-gradient-to-r from-violet-500 to-cyan-400 py-3.5 font-semibold text-ink transition-transform hover:scale-[1.01]"
            >
              {sent ? "Opening your email…" : "Send message"}
            </button>
          </motion.form>
        </div>
      </div>
    </section>
  );
}
