import { motion } from "framer-motion";

const features = [
  {
    icon: "🛡️",
    title: "100% Authentic",
    desc: "Sealed, genuine Apple & Samsung stock with full local warranty — never grey imports.",
  },
  {
    icon: "🚚",
    title: "White-Glove Delivery",
    desc: "Insured, next-day nationwide shipping with real-time tracking to your door.",
  },
  {
    icon: "💳",
    title: "Flexible Payments",
    desc: "0% interest instalments, card, EFT and trade-in credit — your way to upgrade.",
  },
  {
    icon: "🔄",
    title: "Trade-In Bonus",
    desc: "Get up to R6 000 instant credit for your old device, fully data-wiped & certified.",
  },
  {
    icon: "⚙️",
    title: "Free Setup",
    desc: "We transfer your data and set up your new device so it's ready out of the box.",
  },
  {
    icon: "📞",
    title: "Real Human Support",
    desc: "Talk to a specialist 7 days a week — before and long after your purchase.",
  },
];

export default function Features() {
  return (
    <section id="features" className="relative mx-auto max-w-7xl scroll-mt-24 px-5 py-20 sm:py-28">
      <div className="mb-14 max-w-2xl">
        <span className="text-xs font-semibold uppercase tracking-[0.3em] text-cyan-300/70">
          Why CAPE CELL
        </span>
        <h2 className="mt-3 font-display text-3xl font-800 tracking-tight sm:text-5xl">
          A premium experience, <span className="text-gradient">end to end.</span>
        </h2>
      </div>

      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {features.map((f, i) => (
          <motion.div
            key={f.title}
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-50px" }}
            transition={{ duration: 0.5, delay: i * 0.05 }}
            className="group relative overflow-hidden rounded-3xl border border-white/8 bg-white/[0.03] p-7 transition-colors hover:border-white/20"
          >
            <div className="pointer-events-none absolute -right-10 -top-10 h-32 w-32 rounded-full bg-gradient-to-br from-violet-500/10 to-cyan-400/10 blur-2xl transition-opacity duration-500 group-hover:opacity-100 sm:opacity-0" />
            <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-2xl border border-white/10 bg-gradient-to-br from-white/10 to-white/0 text-2xl">
              {f.icon}
            </div>
            <h3 className="font-display text-lg font-700 text-white">{f.title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-white/55">{f.desc}</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
