export default function Footer() {
  return (
    <footer className="relative border-t border-white/5 px-5 pb-10 pt-16">
      <div className="mx-auto max-w-7xl">
        <div className="grid gap-10 lg:grid-cols-4">
          <div className="lg:col-span-2">
            <a href="#top" className="flex items-center gap-2.5">
              <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500 to-cyan-400 text-base font-bold text-ink">C</span>
              <span className="font-display text-lg font-700">CAPE<span className="text-gradient"> CELL</span></span>
            </a>
            <p className="mt-4 max-w-sm text-sm text-white/50">
              Your trusted home for the complete Apple and Samsung ecosystems —
              authentic devices, expert advice and white-glove nationwide delivery.
            </p>
            <div className="mt-5 flex gap-3">
              {["📘", "📸", "🐦", "▶️"].map((s, i) => (
                <a key={i} href="#" className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 bg-white/5 transition-colors hover:bg-white/10">
                  <span className="text-sm">{s}</span>
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="mb-4 text-sm font-semibold text-white">Shop</h4>
            <ul className="space-y-2.5 text-sm text-white/50">
              {["iPhone", "Samsung Galaxy", "Tablets", "Watches", "Audio", "Laptops"].map((x) => (
                <li key={x}><a href="#shop" className="transition-colors hover:text-white">{x}</a></li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="mb-4 text-sm font-semibold text-white">Contact</h4>
            <ul className="space-y-2.5 text-sm text-white/50">
              <li><a href="mailto:capecell021@gmail.com" className="transition-colors hover:text-white">capecell021@gmail.com</a></li>
              <li><a href="tel:0611677250" className="transition-colors hover:text-white">061 167 7250</a></li>
              <li className="text-white/40">Mon–Sun · 8am–8pm</li>
            </ul>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-3 border-t border-white/5 pt-6 text-xs text-white/40 sm:flex-row">
          <span>© {new Date().getFullYear()} CAPE CELL. All rights reserved.</span>
          <span>Apple and Samsung are trademarks of their respective owners.</span>
        </div>
      </div>
    </footer>
  );
}
