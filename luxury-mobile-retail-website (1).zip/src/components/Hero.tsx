import { motion } from "framer-motion";

const stats = [
  { v: "12K+", l: "Devices delivered" },
  { v: "4.9★", l: "Customer rating" },
  { v: "2yr", l: "Warranty cover" },
];

export default function Hero() {
  return (
    <section id="top" className="relative overflow-hidden pt-32 pb-20 sm:pt-40 sm:pb-28">
      <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 lg:grid-cols-2 lg:gap-8">
        {/* copy */}
        <div className="relative z-10 text-center lg:text-left">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mx-auto mb-6 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-1.5 text-xs font-medium text-white/70 backdrop-blur lg:mx-0"
          >
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
            </span>
            Authorised Apple &amp; Samsung ecosystem
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.05 }}
            className="font-display text-4xl font-800 leading-[1.05] tracking-tight sm:text-6xl lg:text-7xl"
          >
            The future,
            <br />
            <span className="text-gradient">beautifully delivered.</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.15 }}
            className="mx-auto mt-6 max-w-xl text-base text-white/60 sm:text-lg lg:mx-0"
          >
            The complete iPhone and Samsung Galaxy ecosystems — phones, tablets,
            watches, audio and laptops. 100% authentic, white-glove delivery
            nationwide.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.25 }}
            className="mt-9 flex flex-col items-center gap-3 sm:flex-row lg:items-start lg:justify-start"
          >
            <a
              href="#shop"
              className="group relative inline-flex w-full items-center justify-center gap-2 overflow-hidden rounded-2xl bg-gradient-to-r from-violet-500 to-cyan-400 px-7 py-3.5 font-semibold text-ink transition-transform hover:scale-[1.02] sm:w-auto"
            >
              <span className="absolute inset-0 -translate-x-full bg-white/30 transition-transform duration-700 group-hover:translate-x-full" />
              Shop the ecosystem
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M13 6l6 6-6 6" /></svg>
            </a>
            <a
              href="#features"
              className="inline-flex w-full items-center justify-center gap-2 rounded-2xl border border-white/15 bg-white/5 px-7 py-3.5 font-semibold text-white backdrop-blur transition-colors hover:bg-white/10 sm:w-auto"
            >
              Why CAPE CELL
            </a>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="mx-auto mt-10 flex max-w-md items-center justify-between gap-4 lg:mx-0"
          >
            {stats.map((s) => (
              <div key={s.l} className="text-center lg:text-left">
                <div className="font-display text-2xl font-700 text-white sm:text-3xl">{s.v}</div>
                <div className="text-xs text-white/50">{s.l}</div>
              </div>
            ))}
          </motion.div>
        </div>

        {/* visual */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
          className="relative mx-auto w-full max-w-md lg:max-w-none"
        >
          <div className="absolute left-1/2 top-1/2 -z-10 h-[120%] w-[120%] -translate-x-1/2 -translate-y-1/2 rounded-full bg-gradient-to-tr from-violet-600/30 via-fuchsia-500/10 to-cyan-400/30 blur-3xl" />
          <div className="animate-float-slow">
            <img
              src="https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=900&q=80"
              alt="Premium iPhone and Samsung Galaxy devices"
              className="mx-auto w-full max-w-md rounded-[2.5rem] border border-white/10 shadow-[0_40px_80px_rgba(120,110,255,0.35)] object-cover"
              loading="eager"
              onError={(e)=>{ (e.currentTarget as HTMLImageElement).src='https://images.pexels.com/photos/404280/pexels-photo-404280.jpeg?auto=compress&cs=tinysrgb&w=900'}}
            />
          </div>
          {/* floating glass cards */}
          <motion.div
            animate={{ y: [0, -14, 0] }}
            transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
            className="glass absolute left-0 top-10 hidden rounded-2xl px-4 py-3 sm:block"
          >
            <div className="text-xs text-white/50">Trade-in bonus</div>
            <div className="font-display text-lg font-700 text-gradient">Up to R6 000</div>
          </motion.div>
          <motion.div
            animate={{ y: [0, 14, 0] }}
            transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
            className="glass absolute bottom-10 right-0 hidden rounded-2xl px-4 py-3 sm:block"
          >
            <div className="text-xs text-white/50">Free next-day</div>
            <div className="font-display text-lg font-700 text-white">Delivery 🚚</div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
