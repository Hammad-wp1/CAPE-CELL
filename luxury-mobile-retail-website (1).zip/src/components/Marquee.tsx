const items = [
  "100% Authentic",
  "2-Year Warranty",
  "Free Next-Day Delivery",
  "Trade-In Welcome",
  "0% Interest Plans",
  "Nationwide Shipping",
  "Apple Authorised",
  "Samsung Authorised",
];

export default function Marquee() {
  return (
    <div className="relative overflow-hidden border-y border-white/5 bg-white/[0.02] py-4">
      <div className="flex w-max marquee-track">
        {[...items, ...items].map((t, i) => (
          <div key={i} className="flex items-center gap-3 px-7 text-sm font-medium text-white/45">
            <span className="h-1.5 w-1.5 rounded-full bg-gradient-to-r from-violet-400 to-cyan-400" />
            {t}
          </div>
        ))}
      </div>
    </div>
  );
}
