import { motion } from "framer-motion";
import { useState } from "react";
import { type Product, formatZar } from "../data/products";
import { useCart } from "../context/CartContext";

export default function ProductCard({ product }: { product: Product }) {
  const { add, lastAdded } = useCart();
  const [active, setActive] = useState(0);
  const justAdded = lastAdded === product.id;

  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.5 }}
      whileHover={{ y: -6 }}
      className="group relative flex flex-col overflow-hidden rounded-3xl border border-white/8 bg-white/[0.03] p-5 backdrop-blur-sm transition-colors hover:border-white/20"
    >
      {/* glow on hover */}
      <div className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-500 group-hover:opacity-100">
        <div className="absolute -top-16 left-1/2 h-40 w-40 -translate-x-1/2 rounded-full bg-violet-500/20 blur-3xl" />
      </div>

      <div className="relative mb-4 flex items-center justify-between">
        <span className="rounded-full border border-white/10 bg-white/5 px-2.5 py-1 text-[11px] font-medium text-white/60">
          {product.brand}
        </span>
        {product.badge && (
          <span className="rounded-full bg-gradient-to-r from-violet-500 to-cyan-400 px-2.5 py-1 text-[11px] font-bold text-ink">
            {product.badge}
          </span>
        )}
      </div>

      {/* device visual */}
      <div className="relative mb-5 flex h-48 overflow-hidden rounded-2xl bg-white/[0.02] border border-white/5 items-center justify-center">
        {/* Soft active color background glow */}
        <div
          className="absolute inset-0 opacity-20 blur-xl transition-all duration-700"
          style={{ background: product.colors[active] }}
        />
        
        {/* Real Product Photo */}
        <motion.div
          key={active}
          initial={{ scale: 0.9, opacity: 0.7 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.4, ease: "easeOut" }}
          className="relative h-full w-full p-2 flex items-center justify-center"
        >
          <img
            src={product.image}
            alt={product.name}
            className="h-full w-full object-cover rounded-xl transition-transform duration-500 group-hover:scale-110"
            loading="lazy"
          />
          {/* Subtle color overlay reflecting chosen color indicator */}
          <div 
            className="absolute inset-2 rounded-xl mix-blend-color opacity-35 pointer-events-none transition-all duration-500"
            style={{ backgroundColor: product.colors[active] }}
          />
        </motion.div>
      </div>

      <h3 className="font-display text-lg font-700 leading-tight text-white">{product.name}</h3>
      <p className="mt-1 text-sm text-white/50">{product.tagline}</p>

      {/* color swatches */}
      <div className="mt-4 flex items-center gap-2">
        {product.colors.map((c, i) => (
          <button
            key={c + i}
            onClick={() => setActive(i)}
            aria-label={`Colour ${i + 1}`}
            className={`h-5 w-5 rounded-full border transition-all ${
              active === i ? "scale-110 border-white ring-2 ring-white/30" : "border-white/20"
            }`}
            style={{ background: c }}
          />
        ))}
      </div>

      <div className="mt-5 flex items-end justify-between gap-3">
        <div>
          <div className="text-[11px] text-white/40">from</div>
          <div className="font-display text-xl font-800 text-white">{formatZar(product.price)}</div>
        </div>
        <button
          onClick={() => add(product)}
          className={`relative inline-flex items-center gap-1.5 overflow-hidden rounded-xl px-4 py-2.5 text-sm font-semibold transition-all ${
            justAdded
              ? "bg-emerald-400 text-ink"
              : "bg-gradient-to-r from-violet-500 to-cyan-400 text-ink hover:scale-105"
          }`}
        >
          {justAdded ? (
            <>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6L9 17l-5-5" /></svg>
              Added
            </>
          ) : (
            <>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 5v14M5 12h14" /></svg>
              Add
            </>
          )}
        </button>
      </div>
    </motion.article>
  );
}
